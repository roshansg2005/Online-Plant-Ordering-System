import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private userAddress = {
    street_address: '123 Main St',
    city: 'Sample City',
    state: 'Sample State',
    postal_code: '12345'
  };

  constructor() {}

  getUserAddress() {
    return this.userAddress;
  }
}
