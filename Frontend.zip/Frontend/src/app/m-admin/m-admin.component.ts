import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-m-admin',
  imports: [FormsModule,CommonModule],
  templateUrl: './m-admin.component.html',
  styleUrl: './m-admin.component.css'
})
export class MAdminComponent {
  customers: any[] = [];
  nurseries: any[] = [];
  selectedUser: any = null;
  selectedUserType: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadCustomers();
    this.loadNurseries();
  }

  loadCustomers() {
    this.http.get('http://localhost:5000/customers').subscribe((data: any) => {
      this.customers = data;
    });
  }

  loadNurseries() {
    this.http.get('http://localhost:5000/nurseries').subscribe((data: any) => {
      this.nurseries = data;
    });
  }

  editCustomer(customer: any) {
    this.selectedUser = { ...customer };
    this.selectedUserType = 'Customer';
  }

  editNursery(nursery: any) {
    this.selectedUser = { ...nursery };
    this.selectedUserType = 'Nursery';
  }

  updateUser() {
    const url = this.selectedUserType === 'Customer' 
      ? `http://localhost:5000/customers/${this.selectedUser.id}` 
      : `http://localhost:5000/nurseries/${this.selectedUser.id}`;

    this.http.put(url, this.selectedUser).subscribe(() => {
      this.selectedUserType === 'Customer' ? this.loadCustomers() : this.loadNurseries();
      this.selectedUser = null;
    });
  }

  deleteCustomer(id: number) {
    this.http.delete(`http://localhost:5000/customers/${id}`).subscribe(() => {
      this.loadCustomers();
    });
  }

  deleteNursery(id: number) {
    this.http.delete(`http://localhost:5000/nurseries/${id}`).subscribe(() => {
      this.loadNurseries();
    });
  }
}