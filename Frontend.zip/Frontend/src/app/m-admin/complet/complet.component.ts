import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-complet',
  imports: [CommonModule,FormsModule],
  templateUrl: './complet.component.html',
  styleUrl: './complet.component.css'
})
export class CompletComponent {
  messages: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchMessages();
  }

  fetchMessages() {
    this.http.get('http://127.0.0.1:5000/showcontact')
      .subscribe(
        (data: any) => this.messages = data,
        (error) => console.error('Error fetching messages', error)
      );
  }
}

