import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // BehaviorSubject stores the latest value and emits it to new subscribers.
  private userNameSubject = new BehaviorSubject<string | null>(null);
  private userRoleSubject = new BehaviorSubject<string | null>(null);
  private profileImageSubject = new BehaviorSubject<string | null>(null); // For Profile Picture
  private profilePicSubject = new BehaviorSubject<string | null>(null); // Separate for profile_pic

  // Expose the BehaviorSubject as observables so other components can subscribe
  userName$ = this.userNameSubject.asObservable();
  userRole$ = this.userRoleSubject.asObservable();
  profileImage$ = this.profileImageSubject.asObservable(); // Profile Image Observable
  profilePic$ = this.profilePicSubject.asObservable(); // Profile Pic Observable

  constructor() {
    // Initialize the service with values from localStorage if they exist
    const userName = localStorage.getItem('userName');
    const userRole = localStorage.getItem('userRole');
    const profileImage = localStorage.getItem('profileImage'); // Get profile image from local storage
    const profilePic = localStorage.getItem('profile_pic'); // Get profile_pic from local storage

    if (userName) {
      this.userNameSubject.next(userName);
    }
    if (userRole) {
      this.userRoleSubject.next(userRole);
    }
    if (profileImage) {
      this.profileImageSubject.next(profileImage);
    }
    if (profilePic) {
      this.profilePicSubject.next(profilePic);
    }
  }

  // Set the user's details and store them in localStorage
  setUserDetails(userName: string, userRole: string): void {
    localStorage.setItem('userName', userName);
    localStorage.setItem('userRole', userRole);
    this.userNameSubject.next(userName);
    this.userRoleSubject.next(userRole);
  }

  // Get the current user's name
  getUserName(): string | null {
    return localStorage.getItem('userName');
  }

  // Get the current user's role
  getUserRole(): string | null {
    return localStorage.getItem('userRole');
  }

  // Set and store profile image separately
  setProfileImage(base64Image: string): void {
    localStorage.setItem('profileImage', base64Image);  // Save the profile image to local storage
    this.profileImageSubject.next(base64Image);         // Update the BehaviorSubject with new image
  }

  // Get profile image
  getProfileImage(): string | null {
    return localStorage.getItem('profileImage');
  }

  // Set and store profile_pic separately
  setProfilePic(base64Image: string): void {
    localStorage.setItem('profile_pic', base64Image);   // Save the profile_pic to local storage
    this.profilePicSubject.next(base64Image);           // Update the BehaviorSubject with new image
  }

  // Get profile_pic
  getProfilePic(): string | null {
    return localStorage.getItem('profile_pic');
  }

  // Remove profile_pic from local storage and reset observable
  clearProfilePic(): void {
    localStorage.removeItem('profile_pic');
    this.profilePicSubject.next(null);
  }

  // Remove profile image from local storage and reset observable
  clearProfileImage(): void {
    localStorage.removeItem('profileImage');
    this.profileImageSubject.next(null);
  }

  // Clear all user details from local storage and reset observables
  clearUserDetails(): void {
    localStorage.removeItem('userName');
    localStorage.removeItem('userRole');
    localStorage.removeItem('profileImage');
    localStorage.removeItem('profile_pic'); // Also remove profile_pic
    this.userNameSubject.next(null);
    this.userRoleSubject.next(null);
    this.profileImageSubject.next(null);
    this.profilePicSubject.next(null);
  }
}
