import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../user.service';  // Ensure you have a service to manage user info
import { CartService } from '../../cart.service';  // Cart service for managing cart

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css'],
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
})
export class PaymentComponent {
  cartItems: any[] = [];
  totalPrice: number = 0;

  // New address fields
  streetAddress: string = '';
  city: string = '';
  postalCode: string = '';
  state: string = '';

  customerName: string = ''; // Will be populated from localStorage
  customerEmail: string = ''; // Will be populated from localStorage
  customerPhone: string = ''; // Will be populated from localStorage
  profilePic: string = ''; // Will be populated from localStorage

  paymentMethod: string = 'COD'; // Default payment method is Cash on Delivery
  status: string = 'Pending'; // Default order status is Pending

  constructor(private http: HttpClient, private router: Router, private userService: UserService, private cartService: CartService) {}

  ngOnInit(): void {
    this.loadCustomerProfile();
    this.loadCart();

  }

  // Load Customer Profile from localStorage
  loadCustomerProfile() {
    const customerProfile = JSON.parse(localStorage.getItem('customerProfile') || '{}');
    if (customerProfile) {
      this.customerName = customerProfile.name || '';
      this.customerEmail = customerProfile.email || '';
      this.customerPhone = customerProfile.phone_number || '';
      this.profilePic = customerProfile.profile_pic || '';
      this.streetAddress = customerProfile.street_address || '';
      this.city = customerProfile.city || '';
      this.postalCode = customerProfile.postal_code || '';
      this.state = customerProfile.state || '';
    }
  }

  // Load Cart from Local Storage
  loadCart() {
    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
      this.cartItems = JSON.parse(storedCart);
      this.calculateTotalPrice();
    }
  }

  // Calculate total price
  calculateTotalPrice() {
    this.totalPrice = this.cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  }

  // Complete the order and mark as COD
  completeOrder() {
    // Prepare order data to send to the backend
    const orderDetails = {
      customerName: this.customerName,
      streetAddress: this.streetAddress,
      city: this.city,
      postalCode: this.postalCode,
      state: this.state,
      cartItems: this.cartItems.map(item => ({
        plant_name: item.plant_name || item.name,  // Handle missing key
        quantity: item.quantity,
        price: item.price
      })),
      paymentMethod: this.paymentMethod,
      status: this.status,
      nurseryEmail: this.cartItems[0]?.nursery_email || '', 
      customerEmail: this.customerEmail 
    };
    
    console.log('Final Order Data:', JSON.stringify(orderDetails, null, 2));
    // Example HTTP POST request to send the order data
    this.http.post('http://localhost:5000/complete-order', orderDetails).subscribe(response => {
      console.log('Order completed:', response);
      // Clear cart after successful order
      this.cartService.clearCart();
      localStorage.removeItem('cart'); // Remove cart from localStorage
      // Redirect user to order confirmation page
      this.router.navigate(['/order-confirmation']);
    }, error => {
      console.error('Error completing order:', error);
      alert('There was an error completing your order. Please try again.');
    });
  }
}
