import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css'],
  imports:[FormsModule,CommonModule]
})
export class AddProductComponent {
  plants: any[] = [];
  filteredPlants: any[] = [];
  isLoggedIn: boolean = !!localStorage.getItem('userToken');

  // Filter Variables
  selectedType: string = "";
  minPrice: number | null = null;
  maxPrice: number | null = null;
  minQuantity: number | null = null;

  // Available Plant Types (Can be dynamic from API)
  plantTypes: string[] = ['Indoor', 'Outdoor', 'Flowering', 'Succulent'];

  constructor(private http: HttpClient,private router:Router) {}

  ngOnInit(): void {
    this.loadPlants();
  }

  // Load All Plants from Backend
  loadPlants() {
    this.http.get<any[]>('http://localhost:5000/showproduct').subscribe({
      next: (response) => {
        console.log('Plants loaded:', response);
        this.plants = response;
        this.filteredPlants = [...this.plants]; // Copy for filtering
      },
      error: (error) => {
        console.error('Error loading plants:', error);
      }
    });
  }

  // Apply Filters
  applyFilters() {
    this.filteredPlants = this.plants.filter(plant => {
      return (
        (!this.selectedType || plant.plant_type === this.selectedType) &&
        (!this.minPrice || plant.price >= this.minPrice) &&
        (!this.maxPrice || plant.price <= this.maxPrice) &&
        (!this.minQuantity || plant.quantity >= this.minQuantity)
      );
    });
  }

  // Reset Filters
  resetFilters() {
    this.selectedType = "";
    this.minPrice = null;
    this.maxPrice = null;
    this.minQuantity = null;
    this.filteredPlants = [...this.plants];
  }

  // View Nursery Profile (Placeholder)
  viewNursery(nurseryEmail: string) {
    const encodedEmail = encodeURIComponent(nurseryEmail); // Encode before navigating
    this.router.navigate(['/nshowprofile', encodedEmail]);
  }
  

  // Add to Cart
  addToCart(plant: any) {
    if (!this.isLoggedIn) {
      alert('You must be logged in to add items to the cart.');
      this.router.navigate(['/login']); // Redirect to login page
      return;
    }

    let cart = localStorage.getItem('cart');
    let cartItems = cart ? JSON.parse(cart) : [];

    const existingPlant = cartItems.find((item: any) => item.id === plant.id);
    if (existingPlant) {
      existingPlant.quantity += 1;
    } else {
      cartItems.push({ ...plant, quantity: 1 });
    }

    localStorage.setItem('cart', JSON.stringify(cartItems));
    alert(`${plant.plant_name} added to cart!`);
  }
}
