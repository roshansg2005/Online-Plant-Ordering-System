import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-product-management',
  templateUrl: './product-management.component.html',
  styleUrls: ['./product-management.component.css'],
  imports: [
    CommonModule,  // Add CommonModule for ngFor, pipes like currency, date
    FormsModule,   // Add FormsModule for [(ngModel)]
    ReactiveFormsModule,  // Add if you're using reactive forms
  ],
})
export class ProductManagementComponent {
  cartItems: any[] = [];

  constructor() {
    const storedCart = localStorage.getItem('cart');
    this.cartItems = storedCart ? JSON.parse(storedCart) : [];
  }

  // Update quantity
  updateQuantity(index: number, event: any) {
    const newQuantity = event.target.value;
    if (newQuantity > 0) {
      this.cartItems[index].quantity = newQuantity;
      this.saveCart();
    }
  }

  // Remove item from cart
  removeFromCart(index: number) {
    this.cartItems.splice(index, 1);
    this.saveCart();
  }

  // Save cart to localStorage
  saveCart() {
    localStorage.setItem('cart', JSON.stringify(this.cartItems));
  }

  // Calculate total price
  getTotalPrice(): number {
    return this.cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  }

  // Proceed to checkout
  checkout() {
    window.location.href = '/payment';    // Redirect to payment page if needed
  }
}