import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css'],
  imports: [CommonModule, FormsModule, ReactiveFormsModule]
})
export class UserProfileComponent {
  customerForm: FormGroup;
  customer: any = {};
  base64Image: string | null = null;
  apiUrl: string = 'http://localhost:5000/';

  constructor(private fb: FormBuilder, private http: HttpClient, private authService: AuthService) {
    this.customerForm = this.fb.group({
      name: ['', Validators.required],
      email: [{ value: '', disabled: true }],
      phone_number: [''],
      street_address: [''],
      city: [''],
      state: [''],
      postal_code: ['']
    });
  }

  ngOnInit(): void {
    const storedCustomer = localStorage.getItem('customerProfile');
    if (storedCustomer) {
      this.customer = JSON.parse(storedCustomer);
      this.customerForm.patchValue(this.customer);
      this.base64Image = this.customer.profile_pic || null;
    } else {
      const email = localStorage.getItem('userEmail');
      if (email) {
        this.getCustomerProfile(email);
      }
    }
  }

  getCustomerProfile(email: string): void {
    this.http.post(`${this.apiUrl}/customerProfile`, { email }).subscribe(
      (response: any) => {
        if (response) {
          this.customer = response;
          this.customerForm.patchValue(response);
          this.base64Image = response.profile_pic || null;

          // Store profile data in local storage
          localStorage.setItem('customerProfile', JSON.stringify(response));
        }
      },
      (error) => {
        console.error('Error fetching customer profile:', error);
      }
    );
  }

  onFileSelected(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.base64Image = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  }

  updateProfile(): void {
    const profileData = {
      ...this.customerForm.value,
      email: this.customer.email,
      profile_pic: this.base64Image
    };

    this.http.post(`${this.apiUrl}/updateProfile`, profileData).subscribe(
      (response: any) => {
        console.log('Profile updated successfully:', response);
        this.getCustomerProfile(this.customer.email);

        // Store updated profile in local storage
        localStorage.setItem('customerProfile', JSON.stringify(profileData));
        window.location.reload();      },
      (error) => {
        console.error('Error updating profile:', error);
      }
    );
  }

  triggerFileInput(): void {
    const fileInput = document.getElementById('profile_pic_input') as HTMLInputElement;
    if (fileInput) {
      fileInput.click();
    }
  }

  viewProfilePic(): void {
    if (this.base64Image) {
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write('<img src="' + this.base64Image + '" />');
      }
    }
  }

  removeProfilePic(): void {
    this.base64Image = null;
    const profileData = { email: this.customer.email, profile_pic: null };

    this.http.post(`${this.apiUrl}/updateProfile`, profileData).subscribe(
      (response: any) => {
        console.log('Profile picture removed successfully:', response);
        this.getCustomerProfile(this.customer.email);

        // Update local storage
        const updatedProfile = { ...this.customer, profile_pic: null };
        localStorage.setItem('customerProfile', JSON.stringify(updatedProfile));
      },
      (error) => {
        console.error('Error removing profile picture:', error);
      }
    );
  }
}
