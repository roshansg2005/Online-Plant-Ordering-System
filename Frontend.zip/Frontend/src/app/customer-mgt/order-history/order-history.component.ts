import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css'],
  imports: [
    CommonModule,  // Add CommonModule for ngFor, pipes like currency, date
    FormsModule,   // Add FormsModule for [(ngModel)]
    ReactiveFormsModule,  // Add if you're using reactive forms
  ],
})
export class OrderHistoryComponent implements OnInit {
  customerEmail: string = ''; // Retrieved from localStorage
  orders: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadCustomerOrders();
  }

  loadCustomerOrders() {
    const storedProfile = JSON.parse(localStorage.getItem('customerProfile') || '{}');
    if (storedProfile?.email) {
      this.customerEmail = storedProfile.email;

      this.http.get(`http://localhost:5000/order-history/${this.customerEmail}`).subscribe(
        (response: any) => {
          this.orders = response;
        },
        (error) => {
          console.error('Error fetching orders:', error);
        }
      );
    }
  }
}