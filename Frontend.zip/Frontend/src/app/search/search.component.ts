import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../product-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-search',
  imports: [CommonModule,FormsModule],
  templateUrl: './search.component.html',
  styleUrl: './search.component.css'
})
export class SearchComponent {
  searchResults: any[] = [];
  query: string = '';
  isLoggedIn: boolean = !!localStorage.getItem('userToken'); // Check login status

  constructor(private route: ActivatedRoute, private productService: ProductService, private router: Router) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.query = params['q'];
      if (this.query) {
        this.fetchSearchResults();
      }
    });
  }

  fetchSearchResults() {
    this.productService.searchProducts(this.query).subscribe(results => {
      this.searchResults = results;
    });
  }

  viewNursery(nurseryEmail: string) {
    console.log("Navigating to nursery:", nurseryEmail);
    this.router.navigate(['nshowprofile', nurseryEmail]);
  }
  

  addToCart(plant: any) {
    if (!this.isLoggedIn) {
      alert('You must be logged in to add items to the cart.');
      this.router.navigate(['/login']); // Redirect to login page
      return;
    }
  
    let cart = localStorage.getItem('cart');
    let cartItems = cart ? JSON.parse(cart) : [];
  
    const existingPlant = cartItems.find((item: any) => item.id === plant.id);
    if (existingPlant) {
      existingPlant.quantity += 1;
    } else {
      cartItems.push({ ...plant, quantity: 1 });
    }
  
    localStorage.setItem('cart', JSON.stringify(cartItems));
    alert(`${plant.plant_name} added to cart!`);
  }
  
}
