import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router) {}

  canActivate(): boolean {
    const isLoggedIn = !!localStorage.getItem('userToken'); // Assuming token is stored on login
    const userRole = localStorage.getItem('userRole'); // Get role from localStorage
    if (userRole === 'admin' || userRole === 'customer'||userRole === 'nursery') {
      return true; // Allow access if 
    } else {
      this.router.navigate(['/login']); // Redirect to login if not admin
      return false;
    }
    
  }
}
