import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NRegisterComponent } from './n-register.component';

describe('NRegisterComponent', () => {
  let component: NRegisterComponent;
  let fixture: ComponentFixture<NRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NRegisterComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
