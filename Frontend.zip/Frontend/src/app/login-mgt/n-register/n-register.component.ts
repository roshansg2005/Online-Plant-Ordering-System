import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-n-register',
  imports: [CommonModule, FormsModule, ReactiveFormsModule,],
  templateUrl: './n-register.component.html',
  styleUrl: './n-register.component.css',
})
export class NRegisterComponent {
  registrationForm: FormGroup;
  otpSent = false;
  otpVerified = false;
  private baseUrl = 'http://localhost:5000';  // Replace with your backend URL

  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router) {
    this.registrationForm = this.fb.group({
      first_name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      business_name: [''],
      phone_number: [''],
      street_address: [''],
      city: [''],
      state: [''],
      postal_code: [''],
      otp: [''],
    });
  }

  // Send OTP
  sendOtp() {
    const email = this.registrationForm.get('email')?.value;
    if (this.registrationForm.get('email')?.valid) {
      // Make API call to send OTP
      this.http.post(`${this.baseUrl}/register/send-otp`, { email }).subscribe(
        (response) => {
          alert('OTP sent successfully');
          this.otpSent = true;
        },
        (error) => {
          alert('Error sending OTP');
        }
      );
    }
  }

  // Verify OTP
  verifyOtp() {
    const email = this.registrationForm.get('email')?.value;
    const otp = this.registrationForm.get('otp')?.value;

    if (otp && email) {
      // Make API call to verify OTP
      this.http.post(`${this.baseUrl}/register/nursery/verify-otp`, { email, otp }).subscribe(
        (response) => {
          alert('OTP verified successfully');
          this.otpVerified = true;
        },
        (error) => {
          alert('Error verifying OTP');
        }
      );
    }
  }

  // Register the user
  register() {
    if (this.registrationForm.valid && this.otpVerified) {
      const userData = {
        first_name: this.registrationForm.get('first_name')?.value,
        email: this.registrationForm.get('email')?.value,
        password: this.registrationForm.get('password')?.value,
        business_name: this.registrationForm.get('business_name')?.value,
        phone_number: this.registrationForm.get('phone_number')?.value,
        street_address: this.registrationForm.get('street_address')?.value,
        city: this.registrationForm.get('city')?.value,
        state: this.registrationForm.get('state')?.value,
        postal_code: this.registrationForm.get('postal_code')?.value,
      };

      // API call to register the nursery
      this.http.post(`${this.baseUrl}/register/nursery`, userData).subscribe(
        (response) => {
          alert('Nursery registered successfully');
          this.router.navigate(['/login']);  // Redirect to success page
        },
        (error) => {
          alert('Error registering nursery',);
        }
      );
    }
  }
}
