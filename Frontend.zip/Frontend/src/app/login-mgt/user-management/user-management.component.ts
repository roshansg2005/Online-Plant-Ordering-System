import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css'],
  imports: [CommonModule, FormsModule, ReactiveFormsModule]
})
export class UserManagementComponent {
  customerForm: FormGroup;
  otpSent = false;
  otpVerified = false;

  constructor(private fb: FormBuilder, private http: HttpClient,private router: Router) {
    this.customerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      otp: [''],
    });
  }

  sendOtp() {
    const email = this.customerForm.get('email')?.value;
    this.http.post('http://localhost:5000/register/customer', { email, name: this.customerForm.get('name')?.value })
      .subscribe(response => {
        alert('OTP sent to', );
        this.otpSent = true;
      }, error => {
        alert('Error sending OTP');
      });
  }

  verifyOtp() {
    const email = this.customerForm.get('email')?.value;
    const otp = this.customerForm.get('otp')?.value;
    this.http.post('http://localhost:5000/register/verify-otp', { email, otp })
      .subscribe(response => {
        alert('OTP verified');
        this.otpVerified = true;
      }, error => {
        alert('Error verifying OTP');
      });
  }

  register() {
    if (this.otpVerified) {
      this.router.navigate(['/login']);
      alert('Customer registered');

    }
  }
}