import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [CommonModule, FormsModule, ReactiveFormsModule,RouterLink]
})
export class LoginComponent {
  loginForm: FormGroup;
  otpSent = false;
  otpVerified = false;

  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router,private authService: AuthService) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      otp: [''],
    });
  }

  sendOtp() {
    const email = this.loginForm.get('email')?.value;
    this.http.post('http://localhost:5000/login/send-otp', { email })
      .subscribe(response => {
        alert('OTP sent to email');
        this.otpSent = true;
      }, error => {
        alert('Error sending OTP');
      });
  }

  verifyOtp() {
    const email = this.loginForm.get('email')?.value;
    const otp = this.loginForm.get('otp')?.value;
    this.http.post('http://localhost:5000/login/verify-otp', { email, otp })
      .subscribe((response: any) => {
        alert('OTP verified');
        this.otpVerified = true;
        this.authService.setUserDetails(response.user_name, response.role);

        // Store the user's name and role in local storage
        localStorage.setItem('userName', response.user_name);
        localStorage.setItem('userRole', response.role);
        localStorage.setItem('userEmail', response.email);


        // Proceed to login or navigate to other pages
        this.login();
      }, error => {
        alert('Error verifying OTP');
      });
  }

  login() {
    if (this.otpVerified) {
      alert('Login Successful');
      this.router.navigate(['/home']).then(() => {
        if (!sessionStorage.getItem('reloaded')) {
          sessionStorage.setItem('reloaded', 'true');
          window.location.reload();
        }
      });
    }
  }
  
}
