import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-nursery-profile',
  imports: [CommonModule,FormsModule],
  templateUrl: './nursery-profile.component.html',
  styleUrl: './nursery-profile.component.css'
})
export class NurseryProfileComponent {
  nursery: any = null;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    const encodedEmail = this.route.snapshot.paramMap.get('email');
    const nurseryEmail = decodeURIComponent(encodedEmail || '');  // Decode back
  
    if (nurseryEmail) {
      this.fetchNurseryDetails(nurseryEmail);
    }
  }
  
  
  
  fetchNurseryDetails(nurseryEmail: string) {
    fetch(`http://127.0.0.1:5000/nurseries/email/${nurseryEmail}`)
      .then(response => response.json())
      .then(data => {
        console.log("API Response:", data);  // Debugging
        if (data.error) {
          console.error("Error:", data.error);
        }
        this.nursery = data;
      })
      .catch(error => console.error('Error fetching nursery details:', error));
  }
  
}