import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css'],
  imports: [CommonModule,FormsModule,HttpClientModule],
})
export class ContactComponent {
  contact = {
    name: '',
    email: '',
    subject: '',
    message: ''
  };

  constructor(private http: HttpClient) {}

  onSubmit() {
    this.http.post('http://127.0.0.1:5000/getcontact', this.contact).subscribe(
      (response) => {
        alert('Message sent successfully!');
        this.contact = { name: '', email: '', subject: '', message: '' }; // Reset form
      },
      (error) => {
        console.error('Error sending message', error);
        alert('Failed to send message. Please try again later.');
      }
    );
  }
}