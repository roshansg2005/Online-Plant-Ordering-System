import { TestBed } from '@angular/core/testing';

import { NurseryServiceService } from './nursery-service.service';

describe('NurseryServiceService', () => {
  let service: NurseryServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NurseryServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
