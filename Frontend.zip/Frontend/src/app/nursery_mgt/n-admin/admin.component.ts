import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
  imports: [FormsModule, CommonModule]
})
export class AdminComponent implements OnInit {
  totalPlants: number = 0;
  totalOrders: number = 0;
  orders: any[] = [];
  nurseryEmail: string = '';

  constructor(private http: HttpClient,private router: Router) {}

  ngOnInit(): void {
    this.nurseryEmail = localStorage.getItem('userEmail') || '';

    if (!this.nurseryEmail) {
      alert('Nursery email not found in localStorage.');
      return;
    }

    this.loadDashboardData();
  }

  loadDashboardData() {
    this.http.get(`http://localhost:5000/nursery-stats?nursery_email=${this.nurseryEmail}`)
      .subscribe((response: any) => {
        this.totalPlants = response.totalPlants;
        this.totalOrders = response.totalOrders;
        this.orders = response.orders;
      });
  }
  managePlants(){
    this.router.navigate(['nadd-product']);

  }
  viewOrders(){
    this.router.navigate(['noder-history']);
    
  }
}