import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NurseryService } from '../../nursery-service.service';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-n-profile',
  imports: [
    CommonModule,         // Add CommonModule for ngFor, pipes like currency, date
    FormsModule,          // Add FormsModule for [(ngModel)]
    ReactiveFormsModule,  // Add ReactiveFormsModule for form handling
  ],
  templateUrl: './n-profile.component.html',
  styleUrls: ['./n-profile.component.css'],
})
export class NProfileComponent implements OnInit {
  nurseryForm: FormGroup;
  base64Image: string | null = null; // Profile picture in base64 format
  email: string | null = null;       // User email
  nurseryImages: string[] = [];      // Stores the list of additional nursery images

  constructor(
    private formBuilder: FormBuilder,
    private nurseryService: NurseryService,
    private sanitizer: DomSanitizer,
    private router: Router,
    private authService: AuthService
  ) {
    // Initialize the form with validation
    this.nurseryForm = this.formBuilder.group({
      nurseryName: ['', Validators.required],
      contactEmail: [{ value: '', disabled: true }],
      contactNumber: ['', Validators.required],
      businessHours: ['', Validators.required],
      streetAddress: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      postalCode: ['', Validators.required],
      description: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    // Get the email from localStorage
    this.email = localStorage.getItem('userEmail');
    if (this.email) {
      // Fetch the profile using the email
      this.nurseryService.getProfile(this.email).subscribe((profile) => {
        this.nurseryForm.patchValue(profile); // Fill the form with the retrieved profile data
        this.base64Image = localStorage.getItem('profileImage') || profile.profileImage; // Fetch from localStorage or API
        this.nurseryImages = profile.nurseryImages || []; // Fetch additional nursery images
      });
    } else {
      // If email is not found in localStorage, redirect to login or another page
      this.router.navigate(['/login']);
    }
  }

  // Handle profile picture upload and save it to localStorage
  onProfilePicSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.base64Image = reader.result as string;
        this.authService.clearProfileImage();       
         localStorage.setItem('profileImage', this.base64Image);  // Save to localStorage as well
      };
      reader.readAsDataURL(file);
    }
  }
  
  

  // Handle additional nursery images upload
  onFilesSelected(event: any): void {
    const files: FileList = event.target.files;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      reader.onload = () => {
        this.nurseryImages.push(reader.result as string); // Add base64 image to the list
      };
      reader.readAsDataURL(file);
    }
  }

  // Trigger file input for profile picture
  triggerProfilePicInput(): void {
    const inputElement: HTMLElement | null = document.getElementById('profile_pic_input');
    if (inputElement) {
      inputElement.click();
    }
  }

  // View the profile picture in a new tab
  viewProfilePic(): void {
    if (this.base64Image) {
      const url = this.sanitizer.bypassSecurityTrustUrl(this.base64Image);
      window.open(url as string, '_blank');
    }
  }

  // Remove the profile picture and clear it from localStorage
  removeProfilePic(): void {
    this.base64Image = null;
    localStorage.removeItem('profileImage'); // Remove profile picture from localStorage
  }

  // Remove nursery image by index
  removeNurseryImage(index: number): void {
    if (index > -1 && index < this.nurseryImages.length) {
      this.nurseryImages.splice(index, 1); // Remove image at the given index
    }
  }

  // Update nursery profile
  updateNurseryProfile(): void {
    if (this.nurseryForm.valid) {
      const updatedProfile = this.nurseryForm.value;
      updatedProfile.profileImage = this.base64Image;
      updatedProfile.nurseryImages = this.nurseryImages;
      updatedProfile.email = this.email;

      console.log('Updated Profile:', updatedProfile); // Debug log

      // Make API call to update the profile
      this.nurseryService.nupdateProfile(updatedProfile).subscribe(() => {
        alert('Profile updated successfully!');
        window.location.reload();  
      }, (error) => {
        console.error('Error updating profile:', error);
        alert('Error updating profile!');
      });
    } else {
      alert('Form is not valid. Please check the input fields.');
    }
  }
}
