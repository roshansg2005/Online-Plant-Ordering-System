import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NProfileComponent } from './n-profile.component';

describe('NProfileComponent', () => {
  let component: NProfileComponent;
  let fixture: ComponentFixture<NProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NProfileComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
