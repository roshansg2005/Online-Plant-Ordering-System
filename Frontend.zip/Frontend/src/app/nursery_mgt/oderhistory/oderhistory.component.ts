import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-oderhistory',
  imports: [FormsModule, CommonModule],
  templateUrl: './oderhistory.component.html',
  styleUrl: './oderhistory.component.css'
})
export class OderhistoryComponent {
  totalPlantsSold: number = 0; // Total quantity of plants sold
  totalSellPrice: number = 0; // Total price of plants sold
  orders: any[] = [];
  filteredOrders: any[] = [];
  nurseryEmail: string = '';
  selectedDate: string = '';
  selectedProduct: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.nurseryEmail = localStorage.getItem('userEmail') || '';

    if (!this.nurseryEmail) {
      alert('Nursery email not found in localStorage.');
      return;
    }

    this.loadDashboardData();
  }

  loadDashboardData() {
    this.http.get(`http://localhost:5000/nursery-orders?nursery_email=${this.nurseryEmail}`)
      .subscribe((response: any) => {
        this.orders = response;
        this.filteredOrders = response; // Initialize with all orders
        this.calculateTotals(); // Calculate total plants sold and total sell price
      });
  }

  filterOrders() {
    this.filteredOrders = this.orders.filter(order => {
      return (
        (this.selectedDate ? order.order_date.startsWith(this.selectedDate) : true) &&
        (this.selectedProduct ? order.product_name.toLowerCase().includes(this.selectedProduct.toLowerCase()) : true)
      );
    });

    this.calculateTotals(); // Update totals after filtering
  }

  calculateTotals() {
    this.totalPlantsSold = this.filteredOrders.reduce((sum, order) => sum + order.quantity, 0);
    this.totalSellPrice = this.filteredOrders.reduce((sum, order) => sum + (order.quantity * order.price), 0);
  }
}