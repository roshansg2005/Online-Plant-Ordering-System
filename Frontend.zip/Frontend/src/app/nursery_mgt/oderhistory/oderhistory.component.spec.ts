import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OderhistoryComponent } from './oderhistory.component';

describe('OderhistoryComponent', () => {
  let component: OderhistoryComponent;
  let fixture: ComponentFixture<OderhistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OderhistoryComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OderhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
