import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-setproduct',
  imports: [
     CommonModule,  // Add CommonModule for ngFor, pipes like currency, date
     FormsModule,   // Add FormsModule for [(ngModel)]
     ReactiveFormsModule,  // Add if you're using reactive forms
   ],
  templateUrl: './setproduct.component.html',
  styleUrl: './setproduct.component.css'
})
export class SetproductComponent {
  plantForm: FormGroup;
  addedPlants: any[] = [];
  visiblePlants: any[] = [];
  editMode: boolean = false;
  editIndex: number | null = null;
  plantTypes: string[] = ['Indoor', 'Outdoor', 'Flowering', 'Succulent'];  // Example plant types
  previewImage: string | null = null;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.plantForm = this.fb.group({
      plantName: ['', Validators.required],
      subName: ['', Validators.required],
      plantType: ['', Validators.required],
      quantity: ['', [Validators.required, Validators.min(1)]],
      description: ['', Validators.required],
      price: ['', [Validators.required, Validators.min(0)]],
      plantImage: [null]
    });
  }

  ngOnInit(): void {
    this.loadPlants(); // Load existing plants on initialization
  }

  // Load plants for the current nursery (based on email stored in localStorage)
  loadPlants() {
    const email = localStorage.getItem('userEmail');
    if (email) {
      this.http.get<any[]>(`http://localhost:5000/plants/${email}`).subscribe(
        response => {
          console.log('Plant data loaded:', response);  // Add this line to log the response
          this.addedPlants = response;
          this.visiblePlants = this.addedPlants.slice(0, 14); // Show first 14 plants
        },
        error => {
          console.error('Failed to load plants:', error);
        }
      );
    }
  }
  // Submit the form to add a new plant or update an existing plant
  onSubmit() {
    const email = localStorage.getItem('userEmail');
    if (!email) {
      alert('No nursery email found in localStorage!');
      return;
    }
  
    if (this.plantForm.invalid) {
      return;
    }
  
    const plantData = {
      ...this.plantForm.value,
      plantImage: this.previewImage,  // Pass the base64 image here
      nursery_email: email
    };
  
    if (this.editMode && this.editIndex !== null) {
      const plantId = this.addedPlants[this.editIndex].id;
      this.http.put(`http://localhost:5000/update_plant/${plantId}`, plantData).subscribe(
        response => {
          this.loadPlants();
          this.resetForm();
        },
        error => {
          console.error('Failed to update plant:', error);
        }
      );
    } else {
      this.http.post('http://localhost:5000/add_plant', plantData).subscribe(
        response => {
          this.loadPlants();
          this.resetForm();
        },
        error => {
          console.error('Failed to add plant:', error);
        }
      );
    }
  }

  // File selection for plant image (convert to base64)
  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.previewImage = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  }

  // Edit an existing plant
  editPlant(index: number) {
    this.editMode = true;
    this.editIndex = index;
    const plant = this.addedPlants[index];
    this.plantForm.patchValue({
      plantName: plant.plant_name,
      subName: plant.sub_name,
      plantType: plant.plant_type,
      quantity: plant.quantity,
      description: plant.description,
      price: plant.price,
      plantImage: null
    });
    this.previewImage = plant.plant_image;
  }

  // Remove a plant
  removePlant(index: number) {
    const plantId = this.addedPlants[index].id;
    this.http.delete(`http://localhost:5000/delete_plant/${plantId}`).subscribe(
      response => {
        this.loadPlants();
      },
      error => {
        console.error('Failed to remove plant:', error);
      }
    );
  }

  // Show more plants (pagination)
  showMore() {
    const nextSet = this.addedPlants.slice(this.visiblePlants.length, this.visiblePlants.length + 14);
    this.visiblePlants = [...this.visiblePlants, ...nextSet];
  }

  // Reset the form after submission or edit cancel
  resetForm() {
    this.editMode = false;
    this.editIndex = null;
    this.previewImage = null;
    this.plantForm.reset();
  }
}