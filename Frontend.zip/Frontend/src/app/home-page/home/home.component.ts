import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { FooterComponent } from '../footer/footer.component';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
 imports: [
     CommonModule,  // Add CommonModule for ngFor, pipes like currency, date
     FormsModule,   // Add FormsModule for [(ngModel)]
     ReactiveFormsModule,  // Add if you're using reactive forms
     FooterComponent,
     RouterLink
   ],
  }
)
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
