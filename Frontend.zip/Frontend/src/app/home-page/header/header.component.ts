import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, FormsModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  searchQuery: string = '';
  userRole: string | null = null;
  userName: string = '';
  profilePic: string = 'assets/default-profile.png'; // Default profile image

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    // Load user details from localStorage
    this.loadUserDetails();

    // Fetch user details from the backend if available
    const userEmail = localStorage.getItem('userEmail');
    if (userEmail) {
      this.http.get(`http://localhost:5000/get-user?email=${userEmail}`).subscribe(
        (response: any) => {
          this.userName = response.name;
          this.profilePic = response.profile_pic || 'profilepic.png';

          // Update localStorage so the changes persist
          localStorage.setItem('userName', this.userName);
          localStorage.setItem('profilePic', this.profilePic);
        },
        (error) => console.error('Error fetching user data:', error)
      );
    }
  }

  loadUserDetails(): void {
    this.userName = localStorage.getItem('userName') || 'User';
    this.profilePic = localStorage.getItem('profilePic') || 'profilepic.png';
    this.userRole = localStorage.getItem('userRole');
  }

  isLoggedIn(): boolean {
    return !!this.userRole;
  }

  hasRole(role: string): boolean {
    return this.userRole === role;
  }

  logout(): void {
    localStorage.removeItem('userName');
    localStorage.removeItem('profilePic');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userRole');
    sessionStorage.removeItem('reloaded');
    this.router.navigate(['/login']);
    window.location.reload();  
  }

  onSearch(): void {
    if (this.searchQuery.trim()) {
      this.router.navigate(['/search'], { queryParams: { q: this.searchQuery } });
      window.location.reload();  

    }
  }
}
