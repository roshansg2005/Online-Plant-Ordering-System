import { Routes } from '@angular/router';
import { HomeComponent } from './home-page/home/home.component';
import { UserManagementComponent } from './login-mgt/user-management/user-management.component';
import { LoginComponent } from './login-mgt/login/login.component';
import { UserProfileComponent } from './customer-mgt/c-profile/user-profile.component';
import { ProductManagementComponent } from './customer-mgt/card/product-management.component';
import { AddProductComponent } from './customer-mgt/add-product/add-product.component';
import { OrderHistoryComponent } from './customer-mgt/order-history/order-history.component';
import { PaymentComponent } from './customer-mgt/payment/payment.component';
import { AdminComponent } from './nursery_mgt/n-admin/admin.component';
import { ContactComponent } from './abouts/contact/contact.component';
import { MAdminComponent } from './m-admin/m-admin.component';
import { NRegisterComponent } from './login-mgt/n-register/n-register.component';
import { AboutComponent } from './abouts/about/about.component';
import { NProfileComponent } from './nursery_mgt/n-profile/n-profile.component';
import { SetproductComponent } from './nursery_mgt/setproduct/setproduct.component';
import { OderhistoryComponent } from './nursery_mgt/oderhistory/oderhistory.component';
import { SearchComponent } from './search/search.component';
import { AuthGuard } from './auth.guard';
import { CompletComponent } from './m-admin/complet/complet.component';
import { NurseryProfileComponent } from './nursery-profile/nursery-profile.component';


export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path:'home',component:HomeComponent},//home page
  { path: 'login', component: LoginComponent },//login page
  { path: 'add-product', component: AddProductComponent },//customer add product
  { path: 'order-history', component: OrderHistoryComponent ,canActivate: [AuthGuard]   },// nursery customer oder history
  { path: 'nadd-product',component:SetproductComponent,canActivate: [AuthGuard]},//nursery add plant
  { path: 'noder-history',component:OderhistoryComponent,canActivate: [AuthGuard]},//nursery oder history
  { path: 'payment', component: PaymentComponent ,canActivate: [AuthGuard]},//customer payment
  { path: 'search', component: SearchComponent },//customer search
  { path: 'n-admin', component: AdminComponent ,canActivate: [AuthGuard]},//nursery admin
  { path: 'm-admin', component: MAdminComponent ,canActivate: [AuthGuard]},//main admin
  { path: 'n-register', component: NRegisterComponent },//nursery register
  { path: 'c-register', component: UserManagementComponent },//customer register
  { path: 'c-profile', component: UserProfileComponent ,canActivate: [AuthGuard]},//customer profile
  { path: 'n-profile', component: NProfileComponent ,canActivate: [AuthGuard]},//nursery profile
  { path: 'abouts', component: AboutComponent },//about page
  { path: 'contact',component:ContactComponent},//contact page
  { path: 'card',component:ProductManagementComponent,canActivate: [AuthGuard]},//card page
  { path: 'complet',component:CompletComponent,canActivate: [AuthGuard]},//complet page
  { path: 'nshowprofile/:email', component: NurseryProfileComponent }//contact page

];
