import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartItems = new BehaviorSubject<any[]>([]);
  cartItems$ = this.cartItems.asObservable();

  constructor() {}

  addToCart(product: any, quantity: number = 1): void {
    let currentCart = this.cartItems.value;
    const existingItem = currentCart.find(item => item.id === product.id);

    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      currentCart.push({ ...product, quantity });
    }

    this.cartItems.next([...currentCart]);
  }

  getCartItems(): any[] {
    return this.cartItems.value;
  }

  clearCart(): void {
    localStorage.removeItem('cart'); // Remove cart from localStorage
  }
}
